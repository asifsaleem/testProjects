package com.example.calculator.vwap;

import com.example.calculator.*;
import com.example.calculator.impl.DefaultMarketUpdate;
import com.example.calculator.impl.TwoWayPriceBuilder;
import org.openjdk.jmh.annotations.State;
import org.openjdk.jmh.annotations.*;
import org.openjdk.jmh.infra.Blackhole;

import java.util.Random;

import static com.example.calculator.State.FIRM;

@State(Scope.Thread)
public class VWAPCalculatorBenchmark {
    private final Calculator vwapCalculator = new VWAPCalculatorImpl();
    private final Calculator vwapCalculatorUsingPrimitives = new VWAPCalculatorUsingPrimitivesImpl();
    private static final int ITERATIONS = 1_000_000;
    private final MarketUpdate[] inputs = new MarketUpdate[ITERATIONS];
    ;
    private final Random random = new Random();

    public VWAPCalculatorBenchmark() {
        for (int i = 0; i < ITERATIONS; i++) {
            TwoWayPriceBuilder twoWayPriceBuilder = new TwoWayPriceBuilder();
            TwoWayPrice nextTwoWayPrice = twoWayPriceBuilder.setState(FIRM)
                    .setInstrument(getInstrument(i))
                    .setBidPrice(9.0 + (i % 100)).
                    setBidAmount(100.0).
                    setOfferPrice(10.0 + (i % 100))
                    .setOfferAmount(100.0)
                    .createDefaultTwoWayPrice();
            inputs[i] = DefaultMarketUpdate.getInstance(getMarket(i), nextTwoWayPrice);
        }
    }

    private Market getMarket(int index) {
        return Market.valueOf("MARKET" + (index % Market.values().length));
    }

    private Instrument getInstrument(int index) {
        return Instrument.valueOf("INSTRUMENT" + (index % Instrument.values().length));
    }

    @Benchmark
    @BenchmarkMode(Mode.All)
    public void applyMarketUpdates(Blackhole bh) {
        bh.consume(vwapCalculator.applyMarketUpdate(inputs[random.nextInt(ITERATIONS)]));
    }

    @Benchmark
    @BenchmarkMode(Mode.All)
    public void applyMarketUpdatesUsingPrimitives(Blackhole bh) {
        bh.consume(vwapCalculatorUsingPrimitives.applyMarketUpdate(inputs[random.nextInt(ITERATIONS)]));
    }
}
