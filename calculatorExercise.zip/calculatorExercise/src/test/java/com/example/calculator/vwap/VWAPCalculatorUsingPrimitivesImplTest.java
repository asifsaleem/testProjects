package com.example.calculator.vwap;

import com.example.calculator.Calculator;
import org.junit.jupiter.api.BeforeEach;

class VWAPCalculatorUsingPrimitivesImplTest extends VWAPCalculatorCommon {

    private Calculator vwapCalculator;

    @BeforeEach
    void setUp() {
        vwapCalculator = new VWAPCalculatorUsingPrimitivesImpl();
        init();
    }

    @Override
    protected Calculator getVWAPCalculator() {
        return vwapCalculator;
    }

}