package com.example.calculator.vwap;

import com.example.calculator.Calculator;
import org.junit.jupiter.api.BeforeEach;

class VWAPCalculatorImplTest extends VWAPCalculatorCommon {

    private Calculator vwapCalculator;

    @BeforeEach
    void setUp() {
        vwapCalculator = new VWAPCalculatorImpl();
        init();
    }

    public Calculator getVWAPCalculator() {
        return vwapCalculator;
    }
}