package com.example.calculator.vwap;

import com.example.calculator.*;
import com.example.calculator.impl.DefaultMarketUpdate;
import com.example.calculator.impl.TwoWayPriceBuilder;
import org.junit.jupiter.api.Test;

import static com.example.calculator.Instrument.INSTRUMENT0;
import static com.example.calculator.Instrument.INSTRUMENT1;
import static com.example.calculator.Market.MARKET0;
import static com.example.calculator.Market.MARKET1;
import static com.example.calculator.State.FIRM;
import static com.example.calculator.State.INDICATIVE;
import static org.junit.jupiter.api.Assertions.assertEquals;

public abstract class VWAPCalculatorCommon {
    protected TwoWayPrice twoWayPrice;
    protected TwoWayPrice twoWayIndicativePrice;
    protected TwoWayPrice twoWayPrice2;
    protected TwoWayPrice twoWayVWAPExpected;
    protected TwoWayPrice twoWayVWAPIndicativeExpected;
    protected TwoWayPrice twoWayVWAPExpected2;
    protected TwoWayPrice twoWayPriceWithInst1;
    protected TwoWayPrice twoWayPrice2WithInst1;
    protected TwoWayPrice twoWayVWAPWithInst1Expected;
    protected TwoWayPrice twoWayVWAPWithInst1Expected2;
    protected TwoWayPrice twoWayPriceWithInst1WithMkt1;
    protected TwoWayPrice twoWayPrice2WithInst1WithMkt1;
    protected TwoWayPrice twoWayVWAPWithInst1WithMkt1Expected;
    protected TwoWayPrice twoWayVWAPWithInst1WithMkt1Expected2;
    protected Market defaultMarket;
    protected Market market1;

    protected void generateRandomPrices(MarketUpdate[] inputs, int iterations) {
        for (int i = 0; i < iterations; i++) {
            TwoWayPriceBuilder twoWayPriceBuilder = new TwoWayPriceBuilder();
            TwoWayPrice nextTwoWayPrice = twoWayPriceBuilder.setState(FIRM)
                    .setInstrument(getInstrument(i))
                    .setBidPrice(9.0 + (i % 100)).
                    setBidAmount(100.0).
                    setOfferPrice(10.0 + (i % 100))
                    .setOfferAmount(100.0)
                    .createDefaultTwoWayPrice();
            inputs[i] = DefaultMarketUpdate.getInstance(getMarket(i), nextTwoWayPrice);
        }
    }

    protected void outputResults(TwoWayPrice[] results, long startTime) {
        System.out.printf("Calculating %s times took %s ms, %n",
                results.length,
                System.currentTimeMillis() - startTime);
        for (int i = 0; i < Instrument.values().length; i++) {
            Instrument instrument = getInstrument(i);
            for (int j = results.length - 1; j >= 0; j--) {
                if (results[j].getInstrument() == instrument) {
                    System.out.printf("Instrument:%s VWAP Bid:%s Offer:%s %n",
                            instrument,
                            results[j].getBidPrice(),
                            results[j].getOfferPrice());
                    break;
                }
            }
        }
    }

    private Market getMarket(int index) {
        return Market.valueOf("MARKET" + (index % Market.values().length));
    }

    private Instrument getInstrument(int index) {
        return Instrument.valueOf("INSTRUMENT" + (index % Instrument.values().length));
    }

    protected void init() {
        defaultMarket = MARKET0;
        market1 = MARKET1;

        TwoWayPriceBuilder twoWayPriceBuilder = new TwoWayPriceBuilder();
        twoWayPrice = twoWayPriceBuilder.setState(FIRM).setInstrument(INSTRUMENT0).setBidPrice(9.0).setBidAmount(100.0).setOfferPrice(10.0).setOfferAmount(100.0).createDefaultTwoWayPrice();
        twoWayPrice2 = twoWayPriceBuilder.setState(FIRM).setInstrument(INSTRUMENT0).setBidPrice(11.0).setBidAmount(100.0).setOfferPrice(12.0).setOfferAmount(100.0).createDefaultTwoWayPrice();
        twoWayIndicativePrice = twoWayPriceBuilder.setState(INDICATIVE).setInstrument(INSTRUMENT0).setBidPrice(13.0).setBidAmount(100.0).setOfferPrice(14.0).setOfferAmount(100.0).createDefaultTwoWayPrice();
        twoWayPriceWithInst1 = twoWayPriceBuilder.setState(FIRM).setInstrument(INSTRUMENT1).setBidPrice(9.0).setBidAmount(100.0).setOfferPrice(10.0).setOfferAmount(100.0).createDefaultTwoWayPrice();
        twoWayPrice2WithInst1 = twoWayPriceBuilder.setState(FIRM).setInstrument(INSTRUMENT1).setBidPrice(11.0).setBidAmount(100.0).setOfferPrice(12.0).setOfferAmount(100.0).createDefaultTwoWayPrice();
        twoWayPriceWithInst1WithMkt1 = twoWayPriceBuilder.setState(FIRM).setInstrument(INSTRUMENT1).setBidPrice(9.0).setBidAmount(100.0).setOfferPrice(10.0).setOfferAmount(100.0).createDefaultTwoWayPrice();
        twoWayPrice2WithInst1WithMkt1 = twoWayPriceBuilder.setState(FIRM).setInstrument(INSTRUMENT1).setBidPrice(11.0).setBidAmount(100.0).setOfferPrice(12.0).setOfferAmount(100.0).createDefaultTwoWayPrice();

        TwoWayPriceBuilder twoWayVWAPBuilder = new TwoWayPriceBuilder();
        twoWayVWAPExpected = twoWayVWAPBuilder.setState(FIRM).setInstrument(INSTRUMENT0).setBidPrice(9.0).setOfferPrice(10.0).createDefaultTwoWayPrice();
        twoWayVWAPExpected2 = twoWayVWAPBuilder.setState(FIRM).setInstrument(INSTRUMENT0).setBidPrice(10.0).setOfferPrice(11.0).createDefaultTwoWayPrice();
        twoWayVWAPIndicativeExpected = twoWayVWAPBuilder.setState(INDICATIVE).setInstrument(INSTRUMENT0).setBidPrice(11.0).setOfferPrice(12.0).createDefaultTwoWayPrice();
        twoWayVWAPWithInst1Expected = twoWayVWAPBuilder.setState(FIRM).setInstrument(INSTRUMENT1).setBidPrice(9.0).setOfferPrice(10.0).createDefaultTwoWayPrice();
        twoWayVWAPWithInst1Expected2 = twoWayVWAPBuilder.setState(FIRM).setInstrument(INSTRUMENT1).setBidPrice(10.0).setOfferPrice(11.0).createDefaultTwoWayPrice();
        twoWayVWAPWithInst1WithMkt1Expected = twoWayVWAPBuilder.setState(FIRM).setInstrument(INSTRUMENT1).setBidPrice(9.0).setOfferPrice(10.0).createDefaultTwoWayPrice();
        twoWayVWAPWithInst1WithMkt1Expected2 = twoWayVWAPBuilder.setState(FIRM).setInstrument(INSTRUMENT1).setBidPrice(10.0).setOfferPrice(11.0).createDefaultTwoWayPrice();
    }

    protected abstract Calculator getVWAPCalculator();

    @Test
    void applySingleMarketUpdateForSingleMarket() {
        MarketUpdate twoWayMarketPrice = DefaultMarketUpdate.getInstance(defaultMarket, twoWayPrice);

        TwoWayPrice vwapActual = getVWAPCalculator().applyMarketUpdate(twoWayMarketPrice);

        assertEquals(twoWayVWAPExpected, vwapActual);
    }

    @Test
    void applyMultipleMarketUpdatesForSingleMarketWithIndicativePrice() {
        MarketUpdate twoWayMarketPrice = DefaultMarketUpdate.getInstance(defaultMarket, twoWayPrice);
        MarketUpdate twoWayMarketPrice2 = DefaultMarketUpdate.getInstance(defaultMarket, twoWayPrice2);
        MarketUpdate twoWayMarketFirmPrice = DefaultMarketUpdate.getInstance(defaultMarket, twoWayIndicativePrice);

        TwoWayPrice vwapActual = getVWAPCalculator().applyMarketUpdate(twoWayMarketPrice);
        System.out.printf("%s %s %s%n", twoWayMarketPrice, getVWAPCalculator(), vwapActual);

        TwoWayPrice vwapActual2 = getVWAPCalculator().applyMarketUpdate(twoWayMarketPrice2);
        System.out.printf("%s %s %s%n", twoWayMarketPrice2, getVWAPCalculator(), vwapActual2);

        TwoWayPrice vwapActual3 = getVWAPCalculator().applyMarketUpdate(twoWayMarketFirmPrice);
        System.out.printf("%s %s %s%n", twoWayMarketFirmPrice, getVWAPCalculator(), vwapActual3);

        assertEquals(twoWayVWAPExpected, vwapActual);
        assertEquals(twoWayVWAPExpected2, vwapActual2);
        assertEquals(twoWayVWAPIndicativeExpected, vwapActual3);
    }

    @Test
    void applyMultipleMarketUpdatesForSingleMarket() {
        MarketUpdate twoWayMarketPrice = DefaultMarketUpdate.getInstance(defaultMarket, twoWayPrice);
        MarketUpdate twoWayMarketPrice2 = DefaultMarketUpdate.getInstance(defaultMarket, twoWayPrice2);

        TwoWayPrice vwapActual = getVWAPCalculator().applyMarketUpdate(twoWayMarketPrice);
        System.out.printf("%s %s %s%n", twoWayMarketPrice, getVWAPCalculator(), vwapActual);

        TwoWayPrice vwapActual2 = getVWAPCalculator().applyMarketUpdate(twoWayMarketPrice2);
        System.out.printf("%s %s %s%n", twoWayMarketPrice2, getVWAPCalculator(), vwapActual2);

        assertEquals(twoWayVWAPExpected, vwapActual);
        assertEquals(twoWayVWAPExpected2, vwapActual2);
    }

    @Test
    void applyMultipleMarketUpdatesForMultipleInstrumentsSingleMarket() {
        MarketUpdate twoWayMarketPrice = DefaultMarketUpdate.getInstance(defaultMarket, twoWayPrice);
        MarketUpdate twoWayMarketPrice2 = DefaultMarketUpdate.getInstance(defaultMarket, twoWayPrice2);
        MarketUpdate twoWayMarketPriceWithInstrument1 = DefaultMarketUpdate.getInstance(defaultMarket, twoWayPriceWithInst1);
        MarketUpdate twoWayMarketPrice2WithInstrument1 = DefaultMarketUpdate.getInstance(defaultMarket, twoWayPrice2WithInst1);

        TwoWayPrice vwapActual = getVWAPCalculator().applyMarketUpdate(twoWayMarketPrice);
        System.out.printf("%s %s %s%n", twoWayMarketPrice, getVWAPCalculator(), vwapActual);

        TwoWayPrice vwapActualWithInstrument1 = getVWAPCalculator().applyMarketUpdate(twoWayMarketPriceWithInstrument1);
        System.out.printf("%s %s %s%n", twoWayMarketPriceWithInstrument1, getVWAPCalculator(), vwapActualWithInstrument1);

        TwoWayPrice vwapActual2 = getVWAPCalculator().applyMarketUpdate(twoWayMarketPrice2);
        System.out.printf("%s %s %s%n", twoWayMarketPrice2, getVWAPCalculator(), vwapActual2);

        TwoWayPrice vwapActual2WithInstrument1 = getVWAPCalculator().applyMarketUpdate(twoWayMarketPrice2WithInstrument1);
        System.out.printf("%s %s %s%n", twoWayMarketPrice2WithInstrument1, getVWAPCalculator(), vwapActual2WithInstrument1);

        assertEquals(twoWayVWAPExpected, vwapActual);
        assertEquals(twoWayVWAPExpected2, vwapActual2);
        assertEquals(twoWayVWAPWithInst1Expected, vwapActualWithInstrument1);
        assertEquals(twoWayVWAPWithInst1Expected2, vwapActual2WithInstrument1);
    }

    @Test
    void applyMultipleMarketUpdatesForMultipleInstrumentsMultipleMarkets() {
        MarketUpdate twoWayMarketPrice = DefaultMarketUpdate.getInstance(defaultMarket, twoWayPrice);
        MarketUpdate twoWayMarketPrice2 = DefaultMarketUpdate.getInstance(defaultMarket, twoWayPrice2);
        MarketUpdate twoWayMarketPriceWithInstrument1 = DefaultMarketUpdate.getInstance(defaultMarket, twoWayPriceWithInst1);
        MarketUpdate twoWayMarketPrice2WithInstrument1 = DefaultMarketUpdate.getInstance(defaultMarket, twoWayPrice2WithInst1);
        MarketUpdate twoWayMarketPriceWithInstrument1WithMarket1 = DefaultMarketUpdate.getInstance(market1, twoWayPriceWithInst1WithMkt1);
        MarketUpdate twoWayMarketPrice2WithInstrument1WithMarket1 = DefaultMarketUpdate.getInstance(market1, twoWayPrice2WithInst1WithMkt1);

        TwoWayPrice vwapActual = getVWAPCalculator().applyMarketUpdate(twoWayMarketPrice);
        System.out.printf("%s %s %s%n", twoWayMarketPrice, getVWAPCalculator(), vwapActual);

        TwoWayPrice vwapActualWithInstrument1 = getVWAPCalculator().applyMarketUpdate(twoWayMarketPriceWithInstrument1);
        System.out.printf("%s %s %s%n", twoWayMarketPriceWithInstrument1, getVWAPCalculator(), vwapActualWithInstrument1);

        TwoWayPrice vwapActual2 = getVWAPCalculator().applyMarketUpdate(twoWayMarketPrice2);
        System.out.printf("%s %s %s%n", twoWayMarketPrice2, getVWAPCalculator(), vwapActual2);

        TwoWayPrice vwapActual2WithInstrument1 = getVWAPCalculator().applyMarketUpdate(twoWayMarketPrice2WithInstrument1);
        System.out.printf("%s %s %s%n", twoWayMarketPrice2WithInstrument1, getVWAPCalculator(), vwapActual2WithInstrument1);

        TwoWayPrice vwapActual2Market1 = getVWAPCalculator().applyMarketUpdate(twoWayMarketPriceWithInstrument1WithMarket1);
        System.out.printf("%s %s %s%n", twoWayPriceWithInst1WithMkt1, getVWAPCalculator(), vwapActual2Market1);

        TwoWayPrice vwapActual2WithInstrument1Market1 = getVWAPCalculator().applyMarketUpdate(twoWayMarketPrice2WithInstrument1WithMarket1);
        System.out.printf("%s %s %s%n", twoWayMarketPrice2WithInstrument1WithMarket1, getVWAPCalculator(), vwapActual2WithInstrument1Market1);

        assertEquals(twoWayVWAPExpected, vwapActual);
        assertEquals(twoWayVWAPExpected2, vwapActual2);
        assertEquals(twoWayVWAPWithInst1Expected, vwapActualWithInstrument1);
        assertEquals(twoWayVWAPWithInst1Expected2, vwapActual2WithInstrument1);
        assertEquals(twoWayVWAPWithInst1WithMkt1Expected, vwapActual2Market1);
        assertEquals(twoWayVWAPWithInst1WithMkt1Expected2, vwapActual2WithInstrument1Market1);
    }

    @Test
    void applyMarketUpdatesForMultipleMarketsMultipleInstruments() {
        int iterations = 1_000_000;
        MarketUpdate[] inputs = new MarketUpdate[iterations];
        TwoWayPrice[] results = new TwoWayPrice[iterations];
        generateRandomPrices(inputs, iterations);
        long startTime = System.currentTimeMillis();
        for (int i = 0; i < iterations; i++) {
            results[i] = getVWAPCalculator().applyMarketUpdate(inputs[i]);
        }
        outputResults(results, startTime);
    }
}
