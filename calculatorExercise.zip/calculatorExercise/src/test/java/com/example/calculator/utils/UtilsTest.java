package com.example.calculator.utils;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.assertEquals;

class UtilsTest {

    @Test
    void round4() {
        Random rand = new Random(1);
        double x = rand.nextDouble(), y = rand.nextDouble();
        double roundedValue = Utils.round4((x + y) / 2);
        BigDecimal expectedValue = BigDecimal.valueOf(x).add(BigDecimal.valueOf(y)).divide(BigDecimal.valueOf(2), 4, RoundingMode.HALF_UP);
        assertEquals(expectedValue.doubleValue(), roundedValue);
    }
}