package com.example.calculator.vwap;

import com.example.calculator.*;
import com.example.calculator.impl.TwoWayPriceBuilder;

import java.math.BigDecimal;
import java.util.Arrays;

import static com.example.calculator.State.INDICATIVE;
import static java.math.RoundingMode.HALF_EVEN;

/**
 * VWAP Calculation
 * The VWAP two-way price for an instrument is defined as:
 * Bid = Sum(Market Bid Price * Market Bid Amount)/ Sum(Market Bid Amount)
 * Offer = Sum(Market Offer Price * Market Offer Amount)/ Sum(Market Offer Amount)
 */
public class VWAPCalculatorImpl implements Calculator {

    public static final int DEFAULT_SCALE = 4;
    private final BigDecimal[][] cumulativeBidPrice;
    private final BigDecimal[][] cumulativeOfferPrice;
    private final BigDecimal[][] cumulativeBidAmount;
    private final BigDecimal[][] cumulativeOfferAmount;
    private final State[][] states;
    private final TwoWayPriceBuilder twoWayPriceBuilder;

    public VWAPCalculatorImpl() {
        cumulativeBidPrice = new BigDecimal[Market.values().length][Instrument.values().length];
        cumulativeOfferPrice = new BigDecimal[Market.values().length][Instrument.values().length];
        cumulativeBidAmount = new BigDecimal[Market.values().length][Instrument.values().length];
        cumulativeOfferAmount = new BigDecimal[Market.values().length][Instrument.values().length];
        states = new State[Market.values().length][Instrument.values().length];
        for (Market market : Market.values()) {
            for (Instrument instrument : Instrument.values()) {
                cumulativeBidPrice[market.ordinal()][instrument.ordinal()] = new BigDecimal(0).setScale(DEFAULT_SCALE, HALF_EVEN);
                cumulativeOfferPrice[market.ordinal()][instrument.ordinal()] = new BigDecimal(0).setScale(DEFAULT_SCALE, HALF_EVEN);
                cumulativeBidAmount[market.ordinal()][instrument.ordinal()] = new BigDecimal(0).setScale(DEFAULT_SCALE, HALF_EVEN);
                cumulativeOfferAmount[market.ordinal()][instrument.ordinal()] = new BigDecimal(0).setScale(DEFAULT_SCALE, HALF_EVEN);
                states[market.ordinal()][instrument.ordinal()] = State.FIRM;
            }
        }
        twoWayPriceBuilder = new TwoWayPriceBuilder();
    }

    @Override
    public TwoWayPrice applyMarketUpdate(MarketUpdate twoWayMarketPrice) {
        TwoWayPrice twoWayPrice = twoWayMarketPrice.getTwoWayPrice();
        int marketIndex = twoWayMarketPrice.getMarket().ordinal();
        int instIndex = twoWayPrice.getInstrument().ordinal();
        cumulativeBidPrice[marketIndex][instIndex] = cumulativeBidPrice[marketIndex][instIndex].add(BigDecimal.valueOf(twoWayPrice.getBidPrice()).multiply(BigDecimal.valueOf(twoWayPrice.getBidAmount())));
        cumulativeBidAmount[marketIndex][instIndex] = cumulativeBidAmount[marketIndex][instIndex].add(BigDecimal.valueOf(twoWayPrice.getBidAmount()));
        cumulativeOfferPrice[marketIndex][instIndex] = cumulativeOfferPrice[marketIndex][instIndex].add(BigDecimal.valueOf(twoWayPrice.getOfferPrice()).multiply(BigDecimal.valueOf(twoWayPrice.getOfferAmount())));
        cumulativeOfferAmount[marketIndex][instIndex] = cumulativeOfferAmount[marketIndex][instIndex].add(BigDecimal.valueOf(twoWayPrice.getOfferAmount()));
        if (twoWayPrice.getState() == INDICATIVE) {
            states[marketIndex][instIndex] = twoWayPrice.getState();
        }
        return twoWayPriceBuilder.setInstrument(twoWayPrice.getInstrument())
                .setState(states[marketIndex][instIndex])
                .setBidPrice(cumulativeBidPrice[marketIndex][instIndex].divide(cumulativeBidAmount[marketIndex][instIndex], DEFAULT_SCALE, HALF_EVEN).doubleValue())
                .setOfferPrice(cumulativeOfferPrice[marketIndex][instIndex].divide(cumulativeOfferAmount[marketIndex][instIndex], DEFAULT_SCALE, HALF_EVEN).doubleValue())
                .createDefaultTwoWayPrice();
    }

    @Override
    public String toString() {
        return "VWAPCalculatorImpl{" +
                "cumulativeBidPrice=" + Arrays.toString(cumulativeBidPrice) +
                ", cumulativeOfferPrice=" + Arrays.toString(cumulativeOfferPrice) +
                ", cumulativeBidAmount=" + Arrays.toString(cumulativeBidAmount) +
                ", cumulativeOfferAmount=" + Arrays.toString(cumulativeOfferAmount) +
                ", states=" + Arrays.toString(states) +
                ", twoWayPriceBuilder=" + twoWayPriceBuilder +
                '}';
    }
}
