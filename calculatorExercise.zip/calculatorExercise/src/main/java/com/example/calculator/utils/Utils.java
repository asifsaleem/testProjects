package com.example.calculator.utils;

public class Utils {

    private static final double FACTOR = 1e4;
    private static final double HALF_UP_CONST = 0.5;

    /**
     * Rounds Half up to 4 decimal places
     * @param x input value
     * @return rounded value to correct decimal places
     */
    public static double round4(double x) {
        return (long) (x * FACTOR + HALF_UP_CONST) / FACTOR;
    }
}