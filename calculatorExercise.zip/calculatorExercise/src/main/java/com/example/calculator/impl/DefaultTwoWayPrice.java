package com.example.calculator.impl;

import com.example.calculator.Instrument;
import com.example.calculator.State;
import com.example.calculator.TwoWayPrice;

import java.util.Objects;

public class DefaultTwoWayPrice implements TwoWayPrice {

    private final Instrument instrument;
    private final State state;
    private final double bidPrice;
    private final double bidAmount;
    private final double offerPrice;
    private final double offerAmount;

    DefaultTwoWayPrice(Instrument instrument, State state, double bidPrice, double bidAmount, double offerPrice, double offerAmount) {
        this.instrument = instrument;
        this.state = state;
        this.bidPrice = bidPrice;
        this.bidAmount = bidAmount;
        this.offerPrice = offerPrice;
        this.offerAmount = offerAmount;
    }

    @Override
    public Instrument getInstrument() {
        return instrument;
    }

    @Override
    public State getState() {
        return state;
    }

    @Override
    public double getBidPrice() {
        return bidPrice;
    }

    @Override
    public double getOfferAmount() {
        return offerAmount;
    }

    @Override
    public double getOfferPrice() {
        return offerPrice;
    }

    @Override
    public double getBidAmount() {
        return bidAmount;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DefaultTwoWayPrice that = (DefaultTwoWayPrice) o;
        return Double.compare(that.bidPrice, bidPrice) == 0 && Double.compare(that.bidAmount, bidAmount) == 0 && Double.compare(that.offerPrice, offerPrice) == 0 && Double.compare(that.offerAmount, offerAmount) == 0 && instrument == that.instrument && state == that.state;
    }

    @Override
    public int hashCode() {
        return Objects.hash(instrument, state, bidPrice, bidAmount, offerPrice, offerAmount);
    }

    @Override
    public String toString() {
        return "DefaultTwoWayPrice{" +
                "instrument=" + instrument +
                ", state=" + state +
                ", bidPrice=" + bidPrice +
                ", bidAmount=" + bidAmount +
                ", offerPrice=" + offerPrice +
                ", offerAmount=" + offerAmount +
                '}';
    }
}
