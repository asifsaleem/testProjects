package com.example.calculator.impl;

import com.example.calculator.Market;
import com.example.calculator.MarketUpdate;
import com.example.calculator.TwoWayPrice;

public class DefaultMarketUpdate implements MarketUpdate {
    private final Market market;
    private final TwoWayPrice twoWayPrice;

    private DefaultMarketUpdate(Market market, TwoWayPrice twoWayPrice) {
        this.market = market;
        this.twoWayPrice = twoWayPrice;
    }

    public static MarketUpdate getInstance(Market market, TwoWayPrice twowayPrice){
        return new DefaultMarketUpdate(market, twowayPrice);
    }

    @Override
    public Market getMarket() {
        return market;
    }

    @Override
    public TwoWayPrice getTwoWayPrice() {
        return twoWayPrice;
    }

    @Override
    public String toString() {
        return "DefaultMarketUpdate{" +
                "market=" + market +
                ", twowayPrice=" + twoWayPrice +
                '}';
    }
}
