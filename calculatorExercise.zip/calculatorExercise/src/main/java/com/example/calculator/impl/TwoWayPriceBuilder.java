package com.example.calculator.impl;

import com.example.calculator.Instrument;
import com.example.calculator.State;

public class TwoWayPriceBuilder {
    private Instrument instrument;
    private State state;
    private double bidPrice;
    private double bidAmount;
    private double offerPrice;
    private double offerAmount;

    public TwoWayPriceBuilder setInstrument(Instrument instrument) {
        this.instrument = instrument;
        return this;
    }

    public TwoWayPriceBuilder setState(State state) {
        this.state = state;
        return this;
    }

    public TwoWayPriceBuilder setBidPrice(double bidPrice) {
        this.bidPrice = bidPrice;
        return this;
    }

    public TwoWayPriceBuilder setBidAmount(double bidAmount) {
        this.bidAmount = bidAmount;
        return this;
    }

    public TwoWayPriceBuilder setOfferPrice(double offerPrice) {
        this.offerPrice = offerPrice;
        return this;
    }

    public TwoWayPriceBuilder setOfferAmount(double offerAmount) {
        this.offerAmount = offerAmount;
        return this;
    }

    public DefaultTwoWayPrice createDefaultTwoWayPrice() {
        return new DefaultTwoWayPrice(instrument, state, bidPrice, bidAmount, offerPrice, offerAmount);
    }
}