package com.example.calculator;

public enum State {
    FIRM, INDICATIVE
}
