package com.example.calculator.vwap;

import com.example.calculator.*;
import com.example.calculator.impl.TwoWayPriceBuilder;
import com.example.calculator.utils.Utils;

import java.util.Arrays;

import static com.example.calculator.State.INDICATIVE;
import static com.example.calculator.utils.Utils.round4;

/**
 * VWAP Calculation using primitives to reduce GC pressure and improve performance
 * The VWAP two-way price for an instrument is defined as:
 * Bid = Sum(Market Bid Price * Market Bid Amount)/ Sum(Market Bid Amount)
 * Offer = Sum(Market Offer Price * Market Offer Amount)/ Sum(Market Offer Amount)
 */
public class VWAPCalculatorUsingPrimitivesImpl implements Calculator {

    private final double[][] cumulativeBidPrice;
    private final double[][] cumulativeOfferPrice;
    private final double[][] cumulativeBidAmount;
    private final double[][] cumulativeOfferAmount;
    private final State[][] states;
    private final TwoWayPriceBuilder twoWayPriceBuilder;

    public VWAPCalculatorUsingPrimitivesImpl() {
        cumulativeBidPrice = new double[Market.values().length][Instrument.values().length];
        cumulativeOfferPrice = new double[Market.values().length][Instrument.values().length];
        cumulativeBidAmount = new double[Market.values().length][Instrument.values().length];
        cumulativeOfferAmount = new double[Market.values().length][Instrument.values().length];
        states = new State[Market.values().length][Instrument.values().length];
        for (Market market : Market.values()) {
            for (Instrument instrument : Instrument.values()) {
                cumulativeBidPrice[market.ordinal()][instrument.ordinal()] = 0.0;
                cumulativeOfferPrice[market.ordinal()][instrument.ordinal()] = 0.0;
                cumulativeBidAmount[market.ordinal()][instrument.ordinal()] = 0.0;
                cumulativeOfferAmount[market.ordinal()][instrument.ordinal()] = 0.0;
                states[market.ordinal()][instrument.ordinal()] = State.FIRM;
            }
        }
        twoWayPriceBuilder = new TwoWayPriceBuilder();
    }

    @Override
    public TwoWayPrice applyMarketUpdate(MarketUpdate twoWayMarketPrice) {
        TwoWayPrice twoWayPrice = twoWayMarketPrice.getTwoWayPrice();
        int marketIndex = twoWayMarketPrice.getMarket().ordinal();
        int instIndex = twoWayPrice.getInstrument().ordinal();
        cumulativeBidPrice[marketIndex][instIndex] = round4(cumulativeBidPrice[marketIndex][instIndex] + (twoWayPrice.getBidPrice() * twoWayPrice.getBidAmount()));
        cumulativeBidAmount[marketIndex][instIndex] = round4(cumulativeBidAmount[marketIndex][instIndex] + twoWayPrice.getBidAmount());
        cumulativeOfferPrice[marketIndex][instIndex] = round4(cumulativeOfferPrice[marketIndex][instIndex] + (twoWayPrice.getOfferPrice() * twoWayPrice.getOfferAmount()));
        cumulativeOfferAmount[marketIndex][instIndex] = round4(cumulativeOfferAmount[marketIndex][instIndex] + twoWayPrice.getOfferAmount());
        if (twoWayPrice.getState() == INDICATIVE) {
            states[marketIndex][instIndex] = twoWayPrice.getState();
        }
        return twoWayPriceBuilder.setInstrument(twoWayPrice.getInstrument())
                .setState(states[marketIndex][instIndex])
                .setBidPrice(round4(cumulativeBidPrice[marketIndex][instIndex] / (cumulativeBidAmount[marketIndex][instIndex])))
                .setOfferPrice(round4(cumulativeOfferPrice[marketIndex][instIndex] / (cumulativeOfferAmount[marketIndex][instIndex])))
                .createDefaultTwoWayPrice();
    }

    @Override
    public String toString() {
        return "VWAPCalculatorUsingPrimitivesImpl{" +
                "cumulativeBidPrice=" + Arrays.toString(cumulativeBidPrice) +
                ", cumulativeOfferPrice=" + Arrays.toString(cumulativeOfferPrice) +
                ", cumulativeBidAmount=" + Arrays.toString(cumulativeBidAmount) +
                ", cumulativeOfferAmount=" + Arrays.toString(cumulativeOfferAmount) +
                ", states=" + Arrays.toString(states) +
                ", twoWayPriceBuilder=" + twoWayPriceBuilder +
                '}';
    }
}
