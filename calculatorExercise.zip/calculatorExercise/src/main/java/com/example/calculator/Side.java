package com.example.calculator;

public enum Side {
    BID, OFFER
}
