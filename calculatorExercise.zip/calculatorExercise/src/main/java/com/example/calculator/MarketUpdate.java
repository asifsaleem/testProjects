package com.example.calculator;

public interface MarketUpdate {
    Market getMarket();
    TwoWayPrice getTwoWayPrice();
}
